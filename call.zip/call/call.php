<?php
	require 'dbconfig.php';
	if(isset($_POST['login'])) {
		$errMsg = '';
		// Get data from FORM
		$email = $_POST['email'];
		$password = $_POST['password'];
		if($email == '')
			$errMsg = 'Enter email';
		if($password == '')
			$errMsg = 'Enter password';
		if($errMsg == '') {
			try {
				$stmt = $connect->prepare('SELECT  name, email, password, FROM tbl_form WHERE email = :email');
				$stmt->execute(array(
					':email' => $email
					));
				$data = $stmt->fetch(PDO::FETCH_ASSOC);
				if($data == false){
					$errMsg = "User $email not found.";
				}
				else {
					if($password == $data['password']) {
						$_SESSION['name'] = $data['name'];
						$_SESSION['email'] = $data['email'];
						$_SESSION['password'] = $data['password'];
						
					
						echo"hello";
					}
					else
						$errMsg = 'Password not match.';
				}
			}
			catch(PDOException $e) {
				$errMsg = $e->getMessage();
			}
		}
	}
?>
