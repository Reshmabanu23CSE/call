<?php
	require 'dbconfig.php';
	if(isset($_POST['submit'])) {
		$errMsg = '';
		// Get data from FROM
		$name = $_POST['name'];
		$email = $_POST['email'];
		$password = $_POST['password'];
		
		if($name == '')
			$errMsg = 'Enter your name';
		if($email == '')
			$errMsg = 'Enter email';
		if($password == '')
			$errMsg = 'Enter password';
		
		if($errMsg == ''){
			try {
				$stmt = $connect->prepare('INSERT INTO tbl_form (name, email, password) VALUES (:name, :email, :password)');
				$stmt->execute(array(
					':name' => $name,
					':email' => $email,
					':password' => $password,
					
					));
						echo"registered";

				exit;
			}
			catch(PDOException $e) {
				echo $e->getMessage();
			}
		}
	}
	
?>

